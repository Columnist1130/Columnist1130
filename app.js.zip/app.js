import express from 'express';
//서버에서 필요한 도구를 제공해주는 친구가 Express. 서버를 만들기위한 도구 제공..
 
const app = express();
// express 실행. app서버를 만들었다.
const PORT = 3000;
// 서버에 주소를 알아야한다. 세부주소라고 한다. 3000번으로 설명했다. localhost. 이 서버만 찾고싶다.
// 3000번을 입력해야한다. column 3000이라고 한다. 쉬프트 세미콜론.....

// Express에서 req.body에 접근하여 body 데이터를 사용할 수 있도록 설정합니다.
app.use(express.json());
// 우리가 만든 서버... use 사용하겠다 뭘 사용하냐면 express json이라는 데이터를 받겠다.
app.use(express.urlencoded({ extended: true }));

// router는 경로를 지정해주는 역할을 하는 객체이다.
const router = express.Router();

// client 요청
// 메서드 GET
// URL "/"  
// 위의 요청이 오면 서버가 
// message: Hi라는 json형식으로 응답한다.
router.get('/', (req, res) => {
  return res.json({ message: '안녕하세요' });
  // return res.json('안녕하세요');
});

router.get('/players', (req, res) => {
  return res.json({ message: '여기는 선수 라우터입니다.' });
});

// app.use -> 미들웨어
// app 이름의 서버가 있다. 
// 근데 그 서버가 /api는 요청을 받으면 router에게 전달한다
app.use('/api', router);

// app이라는 서버를 열겠다. 
// port번호는 3000으로 서버를 연다.
app.listen(PORT, () => {
  console.log(PORT, '포트로 서버가 열렸어요!');
});